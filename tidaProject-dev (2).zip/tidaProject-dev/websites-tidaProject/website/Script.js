import { logPlayer, readUserJSON, readKeysJSON, getUserByLogin } from "./base.js";

let Base = [];
let name, password;
let user = null;

async function init() {
    Base = await readUserJSON();
    name = document.getElementById("log").value;
    password = document.getElementById("pass").value;
    if (logPlayer(Base, name, password)) {
        console.log("You logged");
        user = getUserByLogin(Base, name);
        sessionStorage.setItem('user', JSON.stringify(user)); 
        window.location.replace("Keys.html");
    }
}
async function changeData(name,key,school) {
    Base = await readKeysJSON();
    var Data = null;
    for(var i =0;i<Base.length;i++){
        if(Base[i].school == school){
            Data = Base[i].Data;
            break;
        } 
        
    }

    if(Data != null){
        for(var i =0;i<Data.length;i++){
            if(Data[i].key == key){
                Data[i].name = name
                break;
            } 
            
        }
    }

    const fs = require("fs");
    var change = json.parse(Data);
    fs.writeFile('keysBase.json',change,error =>{ if(error) throw error})
    
}




async function checkIn(id,school){
    var name = prompt("Write your name")
    var str = id + ' - ' + school;
    await changeData(name,id,school)



}
function checkOut(id){
   var yesNo = confirm("Do you wanna give key?")
    if(yesNo){

    }else{

    }


}

async function loadKeys() {
    user = JSON.parse(sessionStorage.getItem('user')); 
    Base = await readKeysJSON();
    const keysContainer = document.getElementById('keysContainer');
    keysContainer.innerHTML = ''; 

    for (let i = 0; i < Base.length; i++) {
        if (user && user.school === Base[i].school) {
            const schoolData = Base[i].Data;
            schoolData.forEach(keyData => {
                const keyElement = document.createElement('div');
                keyElement.classList.add('key-item');
                keyElement.innerHTML = `
                    <h3>Key: ${keyData.key}</h3>
                    <p>Name: ${keyData.Name}</p>
                    <p>Key Taken Date: ${keyData.KeyTakenDate}</p>
                    <p>Key Taken Time: ${keyData.KeyTakenTime}</p>
                    <p>Key Given Date: ${keyData.KeyGivenDate}</p>
                    <p>Key Given Time: ${keyData.KeyGivenTime}</p>
                    <button onclick='checkIn(\"${keyData.key}\",\"${user.school}\")'>lock key </button> <button onclick='checkOut(\"${keyData.key}\")'>unlock key </button>
                `;
                keysContainer.appendChild(keyElement);
            });
        }
    }
}

window.loadKeys = loadKeys;
window.init = init;
window.checkIn = checkIn;
window.checkOut = checkOut;